# Addept Automotive — section 2 "About" redesign (S2-3)

Approved redesign of the **second section** (`id: "about"`, the engine-bay
scene) in `deploy/embed.js`. The hero's corner-bracket grammar carries into
this frame; all animations stay on the existing engine, untouched.

`About Final reference.html` in this folder shows the approved frame (S2-3 —
ignore the other four variations in the file; S2-3 is the one to build).

## What changes

1. **Headline** — same words ("First-rate repairs. / Top-tier care.") but:
   smaller (44px-class instead of the giant 64px), "Top-tier care." **dimmed**
   to 45% white, and the whole statement framed by the hero's **corner
   brackets** instead of the two hairlines above/below.
2. **Lead copy** — replaced with: `From a simple service to advanced
   electrical diagnostics. Got the fault three garages gave up on? We collect
   those.`
3. Everything else (centered layout, scene stop 18, enter/exit drift) stays.

## How animations are preserved

The headline keeps `alp-split` (word-by-word population) and the lead keeps
`alp-rise`. The two `alp-hr` hairlines are **removed** from this section —
no other section is affected. The bracket corner `<i>`s are static children
that fade with the section, same as the hero's.

## 1. Replace the "about" SEC entry (~line 275)

```js
{ id: "about", stop: 18, enter: [0, 10], exit: [0, -10], html:
  '<div class="alp-inner alp-center">'
  + '<div class="alp-hbrk alp-hbrk-c">'
  +   '<i class="tl"></i><i class="tr"></i><i class="bl"></i><i class="br"></i>'
  +   '<h2 class="alp-abouth alp-split">First-rate repairs.\nTop-tier care.</h2>'
  + "</div>"
  + '<p class="alp-lead alp-rise" style="margin-top:26px;">From a simple service to advanced electrical diagnostics. Got the fault three garages gave up on? We collect those.</p>'
  + "</div>" },
```

(Keep the entry's existing `stop`/`enter`/`exit` values if they differ from
the above — only the `html` changes.)

## 2. CSS — add near the hero-bracket rules from the hero handoff

The `.alp-hbrk` rules ship in `handoff-hero/README.md`. If that handoff is
already applied, add only these three:

```js
+ ".alp-abouth{font-family:'Space Grotesk',Inter,sans-serif;font-weight:500;line-height:1.04;letter-spacing:.005em;text-transform:uppercase;font-size:clamp(1.5rem,2.6vw,2.1rem);}"
+ ".alp-abouth .alp-l:last-child .alp-w{color:rgba(255,255,255,.45);}"
+ ".alp-hbrk-c{padding:18px 26px 16px;margin:0;}"
```

Notes:
- `.alp-hbrk-c` overrides the hero bracket's negative left margin and right
  corner insets aren't needed here — all four corners sit at the box edges
  (the hero's 72px/5px optical offsets are hero-only; if your `.alp-hbrk`
  base rule includes them, neutralize with `.alp-hbrk-c i.tr,.alp-hbrk-c
  i.br{right:0;} .alp-hbrk-c i.br{bottom:0;}`).
- The dimmed second line: the split engine wraps each line in `.alp-l` and
  each word in `.alp-w` — the `:last-child` selector dims the second line's
  words without touching the markup. If the engine's classes differ, check
  how `alp-split` decorates lines (~line 599) and target the second line's
  words equivalently.

If the hero handoff is **not** yet applied, also add its `.alp-hbrk` base
rules (see `handoff-hero/README.md` §3) and the Space Grotesk font weights
(§1).

## Acceptance checklist

- [ ] Section 2 shows the bracketed statement (44px-class caps, second line dimmed) with NO hairlines, then the new lead
- [ ] Brackets hug the statement and stay clear of the receptionist at desktop widths
- [ ] Headline words still populate one-by-one; lead still rises; section drift unchanged
- [ ] Other sections (hero, services, inspections…) unaffected
- [ ] Compare against S2-3 in `About Final reference.html`
